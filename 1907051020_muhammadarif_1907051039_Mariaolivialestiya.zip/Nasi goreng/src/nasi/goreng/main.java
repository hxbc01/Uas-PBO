
package nasi.goreng;


public class main {

    
    public static void main(String[] args) {
       Bahan_bahan nasgor = new Bahan_bahan ("Nasi goreng");
       nasgor.tampil();
       
    }
    
}


package nasi.goreng;


public interface Pembuat {
    public String nama_pembuat = "via";
    
    public void Pembuatan();
}
